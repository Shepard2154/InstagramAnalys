from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired


class FriendForm(FlaskForm):
    me = StringField('', id='Instagram', render_kw={"placeholder": "https://www.instagram.com/crocinc/", "autocomplete":"on"},
                     validators=[DataRequired()])
    submit = SubmitField('Отправить')
