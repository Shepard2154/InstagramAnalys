from app import app
from flask import render_template, flash, redirect, request
import requests
from bs4 import BeautifulSoup
from forms import FriendForm
from selenium import webdriver
import requests
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
import time
import re
import pandas as pd
import matplotlib.pyplot as plt


@app.route("/", methods=['GET', 'POST'])
def index():
    form = FriendForm()
    if form.validate_on_submit():
        if request.method == 'POST':
            response = request.form['me']
            t = requests.get(response)
            count = 0
            chromedriver = 'Google/chromedriver.exe'
            options = webdriver.ChromeOptions()
            # options.add_argument('headless')  # для открытия headless-браузера

            browser = webdriver.Chrome(executable_path=chromedriver, options=options)
            browser.implicitly_wait(10)  # seconds

            browser.get('https://www.instagram.com/')
            time.sleep(2)

            login = browser.find_element_by_name("username")
            password = browser.find_element_by_name('password')

            login.send_keys('olegburn010')
            password.send_keys('jktu89501!')
            enter_but = browser.find_element_by_xpath("//button[@type='submit']").click()
            time.sleep(5)

            headers = {'User-Agent': 'Mozilla/5.0'}
            response = requests.get("https://www.instagram.com/murmuurrr/", headers=headers)
            if response.ok:

                browser.get("https://www.instagram.com/murmuurrr/")

                lenOfPage = browser.execute_script(
                    "window.scrollTo(0, document.body.scrollHeight);var lenOfPage=document.body.scrollHeight;return lenOfPage;")
                time.sleep(2)

                hrefcontainer = set()

                with open("instaParse.txt", 'w', encoding='utf-8') as myfile:
                    myfile.write("")
                match = False
                while not match:
                    lastCount = lenOfPage
                    lenOfPage = browser.execute_script(
                        "window.scrollTo(0, document.body.scrollHeight);var lenOfPage=document.body.scrollHeight;return lenOfPage;")
                    time.sleep(3)  # 9

                    try:
                        element = browser.find_element_by_xpath("//div[@class='v1Nh3 kIKUG  _bz0w']")
                        if element.is_enabled():
                            count = count + 1
                            # print(count)
                        html = element.get_attribute('innerHTML')
                        result = re.findall(r"/p/\w*/", str(html))
                        hrefcontainer.add(str(result))

                    except NoSuchElementException:
                        print('o No in loop')
                    if lastCount == lenOfPage:
                        match = True

                time.sleep(10)

                # link = None
                # try:
                #     # elements = browser.find_elements_by_xpath("//div[@class='v1Nh3 kIKUG  _bz0w']")
                #     # html = elements.get_attribute('outerHTML')
                #     html = browser.execute_script("return document.body.outerHTML;")
                #     for triple in html:
                #         print(triple)
                # except NoSuchElementException:
                #     print('o No')

                # requiredHtml = browser.page_source
                # time.sleep(10)
                with open("instaParse.txt", 'a', encoding='utf-8') as myfile:
                    for ref in hrefcontainer:
                        if ref != '[]':
                            myfile.write(str(ref) + '\n')

                lst = []

                with open("instaParse.txt", 'r', encoding='utf-8') as myfile2:
                    for shortc in myfile2:
                        lst.append(shortc[5:-4])

                likes = []

                for rety in range(len(lst)):
                    link = 'https://www.instagram.com/murmuurrr/p/' + lst[rety]
                    browser.get(link)
                    time.sleep(5)
                    like = ''
                    html = browser.page_source
                    reg = str(re.findall(r'<span>\d+', html))
                    for i in reg:
                        if i.isdigit():
                            like += i
                    likes.append(int(like))
                # print(likes)

                da1 = pd.DataFrame({'Likes': likes})
                mean = da1['Likes'].mean()  # Среднее арифметическое
                std = da1['Likes'].std()  # СКО
                mean = round(mean)
                std = round(std)

                assessmen1 = []
                i = 0
                poCom = mean + std
                poCom = round(poCom)
                otCom = mean - std
                otCom = round(otCom)
                for lera in range(len(likes)):
                    l1 = likes[i]
                    if l1 > poCom:
                        pa = l1
                        pa = round(pa)
                        assessmen1.append(pa)
                    elif otCom < l1 < poCom:
                        na = l1
                        assessmen1.append(na)
                    elif l1 < otCom:
                        oa = l1
                        oa = round(oa)
                        assessmen1.append(oa)
                    i = i + 1
                max_ass = max(assessmen1)
                sum_ass = sum(assessmen1)
                j = 0
                k = 0
                pro_assessment = []
                pro_assessment1 = []
                for dasha in range(len(assessmen1)):
                    lin_per = assessmen1[j]
                    pro_ass = lin_per * 100 / max_ass
                    pro_ass1 = round(pro_ass)
                    pro_assessment.append(pro_ass1)
                    j = j + 1

                for darya in range(len(assessmen1)):
                    lin_per = assessmen1[k]
                    pro_ass2 = lin_per * 100 / sum_ass
                    pro_ass3 = round(pro_ass2)
                    pro_assessment1.append(pro_ass3)
                    k = k + 1

                link_sim = lst

                do = pd.DataFrame({'Link': link_sim,
                                   'Rating': assessmen1,
                                   'Percent, %': pro_assessment1})
                print(
                    "Для расчета рейтинга популярности постов на определенном выше аккаунте Instagram был составлен параметр Rating, который рассчитывается из количества лайков.")
                print(
                    "В крайнем столбце топов указан процент популярности каждого поста относительно их суммарного рейтинга.",
                    end='\n\n')

                print("Топ 5 самых популярных постов:", end='\n\n')
                dol_5 = do.sort_values(by='Rating', ascending=False).head()  # топ лучших
                top_max = dol_5[::].reset_index(drop=True)
                print(top_max)
                numbers = [0, 1, 2, 3, 4]
                xa = numbers
                ya = top_max['Percent, %']
                fig, ax = plt.subplots()

                ax.bar(xa, ya,
                       color='chartreuse')

                ax.set_xlabel('Номер ссылки в таблице')
                ax.set_ylabel('Процент популярности')
                ax.set_facecolor('seashell')
                fig.set_facecolor('floralwhite')
                fig.set_figwidth(6)  # ширина Figure
                fig.set_figheight(6)  # высота Figure

                plt.show()

                print("Топ 5 самых непопулярных постов:", end='\n\n')
                dox_5 = do.sort_values('Rating').head()  # топ худших
                top_min = dox_5[::].reset_index(drop=True)
                print(top_min)
                x = numbers
                y = top_min['Percent, %']
                fig, ax = plt.subplots()

                ax.bar(x, y,
                       color='red')

                ax.set_xlabel('Номер ссылки в таблице')
                ax.set_ylabel('Процент популярности')
                ax.set_facecolor('seashell')
                fig.set_facecolor('floralwhite')
                fig.set_figwidth(6)  # ширина Figure
                fig.set_figheight(6)  # высота Figure

                plt.show()
            return render_template('newindex.html', title='Home', soup=soup)

    return render_template('index.html', title='CROCK TASK', form=form)

