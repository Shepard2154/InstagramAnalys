from app import app
from flask import render_template, flash, redirect, request
import requests
from bs4 import BeautifulSoup
from forms import FriendForm


@app.route("/", methods=['GET', 'POST'])
def index():
    form = FriendForm()
    if form.validate_on_submit():
        if request.method == 'POST':
            response = request.form['me']
            t = requests.get(response)

            return render_template('newindex.html', title='Home', soup=soup)

    return render_template('index.html', title='CROCK TASK', form=form)

